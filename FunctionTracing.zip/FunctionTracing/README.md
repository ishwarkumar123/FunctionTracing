# MethodTraceAnalyzer-CodeFreak-

# A Program to view logs interactively.

## How to run the program

To run the application :- Go to the Application directiory i.e. C:\MethodTraceAnalyzer>
and type- MethodTraceAnalyzer.jar

```
To test the program you will need the trace files.
Some of the trace files are included.

## About the project
Performs two basic tasks:-
1. Parses the trace file then shows the table and a BarChart.
2. and can compare two log files with each other in terms of common critical method.


## Acknowledgment

* JFreeChart OpenSource libraries were used to create charts in the project. http://www.jfree.org/jfreechart/
